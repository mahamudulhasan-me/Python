from django.shortcuts import render
from . import forms
from . import models
from django.db.models import Avg

# Create your views here.
def index(request):
    musician = models.Musician.objects.order_by('first_name')
    diction={
        'title':'Index',
        'musician': musician,
    }
    return render(request, 'home/index.html', context=diction)

def add_musician(request):
    musician_form = forms.MusicianForm()
    diction = {
        'title': 'Add Musician',
        'musician_form': musician_form,
    }
    if request.method == 'POST':
        musician_form  = forms.MusicianForm(request.POST)

        if musician_form.is_valid:
            musician_form.save(commit=True)
            return index(request)
    return render(request, 'home/add_musician.html', context=diction)

def add_album(request):
    album_list = forms.AlbumForm()
    diction = {
        'title': 'Add Album',
        'album': album_list,
    }
    if request.method == 'POST':
        album_list = forms.AlbumForm(request.POST)

        if album_list.is_valid():
            album_list.save(commit=True)
            return index(request)
    return render(request, 'home/add_album.html', context=diction)

def musician_info(request, musician_id):
    musician = models.Musician.objects.get(pk=musician_id)
    album = models.Album.objects.filter(artist=musician).order_by('name', 'release_date')
    album_rating_avg = models.Album.objects.filter(artist=musician).aggregate(Avg('num_stars'))
    diction = {
        'title': 'Musician Info',
        'musician': musician,
        'album': album,
        'album_rating_avg': album_rating_avg
    }
    return render(request, 'home/musician_album.html', context=diction)

def update_info(request, update_id):
    update_infos = models.Musician.objects.get(pk=update_id)
    update_form = forms.MusicianForm(instance=update_infos)
    
    if request.method == 'POST':
        update_form=forms.MusicianForm(request.POST, instance=update_infos)

        if update_form.is_valid():
            update_form.save(commit=True)
            return musician_info(request, update_id)
    
    diction = {
        'title': 'Update Info',
        'update_form': update_form,
    }
            
    return render(request, 'home/update_info.html', context=diction)

def update_album(request, album_id):
    getAlbum_info = models.Album.objects.get(pk=album_id)
    update_album_form = forms.AlbumForm(instance=getAlbum_info)
    diction={}
    if request.method == 'POST':
        update_album_form = forms.AlbumForm(request.POST, instance=getAlbum_info)

        if update_album_form.is_valid():
            update_album_form.save(commit=True)
            diction.update({'success_msg': 'Update Successfully!'})

    diction.update({
        'title': 'Update Album',
        'update_album_form': update_album_form,
        })
    diction.update({'album_id':album_id})
    return render(request, 'home/update_album.html', context=diction)

def delete_album(request, album_id):
    album_delete = models.Album.objects.get(pk=album_id).delete()
    diction={
        'title': 'Delete Album',
        'delete_msg': 'Album Deleted Successfully!!'
    }
    return render(request, 'home/delete_page.html', context=diction)

def delete_musician(request, musician_id):
    musician_delete = models.Musician.objects.get(pk=musician_id).delete()
    diction={
        'title': 'Delete Musician',
        'delete_msg': 'Musician Deleted Sucessfully!!'
    }
    return render(request, 'home/delete_page.html', context=diction)